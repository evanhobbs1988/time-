from django.shortcuts import render, HttpResponse, redirect
import time,os

os.environ['TZ']='US/Pacific'
time.tzset()

def index(request):
    context={
        'date':time.strftime("%b %d, %Y", time.localtime()),
        'time':time.strftime("%H:%M %p", time.localtime())
    }

    return render(request,'clock/index.html',context)